-- MySQL dump 10.13  Distrib 5.1.63, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: pbbg_development
-- ------------------------------------------------------
-- Server version	5.1.63-0ubuntu0.11.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `active_admin_comments`
--

DROP TABLE IF EXISTS `active_admin_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_admin_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resource_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `author_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `namespace` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_admin_notes_on_resource_type_and_resource_id` (`resource_type`,`resource_id`),
  KEY `index_active_admin_comments_on_namespace` (`namespace`),
  KEY `index_active_admin_comments_on_author_type_and_author_id` (`author_type`,`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_admin_comments`
--

LOCK TABLES `active_admin_comments` WRITE;
/*!40000 ALTER TABLE `active_admin_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `active_admin_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_admin_users_on_email` (`email`),
  UNIQUE KEY `index_admin_users_on_reset_password_token` (`reset_password_token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'len@touringplans.com','$2a$10$eXoOc/4bPsbX8aElGD.4iu7QWK9GjoAoD4heyEbnvKSV6FYtO7fHS',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clean` tinyint(1) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `accuracy` int(11) DEFAULT NULL,
  `evasion` int(11) DEFAULT NULL,
  `endurance` int(11) DEFAULT NULL,
  `min_deputies` int(11) DEFAULT NULL,
  `max_deputies` int(11) DEFAULT NULL,
  `deputy_type` int(11) DEFAULT NULL,
  `gun` int(11) DEFAULT NULL,
  `deputy_gun` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` VALUES (1,'a Castmember',0,15,35,25,50,0,3,1,3,2,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(2,'a Manager',1,25,35,45,75,2,4,2,4,3,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(3,'another Guest selling FASTPASSes',1,45,55,45,100,3,5,3,6,4,'2012-06-23 16:45:22','2012-06-23 16:45:22');
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bags`
--

DROP TABLE IF EXISTS `bags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bags`
--

LOCK TABLES `bags` WRITE;
/*!40000 ALTER TABLE `bags` DISABLE KEYS */;
/*!40000 ALTER TABLE `bags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_amount` int(11) DEFAULT NULL,
  `loan_interest` int(11) DEFAULT NULL,
  `savings_account` int(11) DEFAULT NULL,
  `interest` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banks`
--

LOCK TABLES `banks` WRITE;
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
INSERT INTO `banks` VALUES (1,6655,10,0,1,1,'2012-06-23 16:46:12','2012-06-30 00:17:24');
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clean` tinyint(1) DEFAULT NULL,
  `enemy_chance` int(11) DEFAULT NULL,
  `event_chance` int(11) DEFAULT NULL,
  `min_units` int(11) DEFAULT NULL,
  `max_units` int(11) DEFAULT NULL,
  `always_unit` int(11) DEFAULT NULL,
  `bank` tinyint(1) DEFAULT NULL,
  `loanshark` tinyint(1) DEFAULT NULL,
  `shop` tinyint(1) DEFAULT NULL,
  `pub` tinyint(1) DEFAULT NULL,
  `hospital` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Main Street',1,0,15,9,14,NULL,0,0,0,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(2,'Adventureland',1,0,15,8,14,15,0,0,1,1,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(3,'Frontierland',1,0,10,9,15,NULL,1,0,0,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(4,'Fantasyland',1,50,5,7,14,16,0,0,1,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(5,'Tomorrowland',1,70,25,6,12,6,1,0,0,1,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(6,'Liberty Square',1,15,20,7,13,5,0,0,1,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(7,'Cosmic Ray\'s Starlight Cafe',1,90,5,5,11,3,1,0,0,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(8,'The WDW Railroad',1,20,5,7,13,9,0,0,0,0,0,'2012-06-23 16:45:22','2012-06-23 16:45:22');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drugs`
--

DROP TABLE IF EXISTS `drugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drugs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clean` tinyint(1) DEFAULT NULL,
  `low_price` int(11) DEFAULT NULL,
  `high_price` int(11) DEFAULT NULL,
  `cheap_chance` int(11) DEFAULT NULL,
  `cheap_str` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cheap_str2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cheap_divide` int(11) DEFAULT NULL,
  `expensive_chance` int(11) DEFAULT NULL,
  `expensive_str` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expensive_str2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expensive_multiply` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drugs`
--

LOCK TABLES `drugs` WRITE;
/*!40000 ALTER TABLE `drugs` DISABLE KEYS */;
INSERT INTO `drugs` VALUES (1,'Space Mountain FASTPASSes',0,11,60,10,'A Castmember shows up and starts giving out Space Mountain FASTPASSes!','Space Mountain FASTPASS machines go crazy! ',4,5,'Space Mountain goes offline temporarily!  FASTPASS prices go up!','Management puts Space\'s standby line outside to save on air-conditioning costs.  FASTPASS prices take off like a rocket!',2,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(2,'Buzz LIghtyear FASTPASSes',0,17,82,10,'Someone from management starts throwing Buzz FASTPASSes from the top of the Astro Orbiter.','Electrical surge in Tomorrowland results in too many Buzz FASTPASSes.',4,5,'Buzz Lightyear\'s a/c is extra-cold.  FASTPASS prices jump!','Rumor of new targets at Buzz increase FASTPASS prices.',3,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(3,'Winnie the Pooh FASTPASSes',0,90,250,0,NULL,NULL,NULL,10,'Rumor says Pooh is out of FASTPASSes.  Parents panic, pushing prices up!','Crowds seek escape from heat.  Pooh FASTPASS prices jump.',4,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(4,'Dumbo FASTPASSes',0,220,700,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(5,'Peter Pan FASTPASSes',0,315,890,10,'System error at Peter Pan causes too many FASTPASSes to be given.','Mysterious crocodile spotted handing out Peter Pan FASTPASSes.',4,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(6,'Splash Mountain FASTPASSes',0,480,1280,10,'Lightning in the area.  No one wants Splash FASTPASSes.','Talking chickens give too many people the willies.  Splash FASTPASS prices drop as a result.',4,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(7,'Big Thunder Mountain FASTPASSes',0,540,1250,0,'',NULL,NULL,10,'Big Thunder standby waits are outrageous.  Crowds scream for FASTPASSes.','Tour group takes huge chunk of Big Thunder FASTPASSes, leaving less for everyone else.  Sellers rejoyce.',4,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(8,'Jungle Cruise FASTPASSes',0,630,1300,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(9,'Bottles of Water',0,450,1600,5,'What\'s this?  A new, ice-cold water fountain appears out of nowhere.  Water prices drop.  Disney magic!','Looming storm clouds hide the sun, cooling off crowds and dropping demand for water.',4,5,'Surprise heat wave makes crowds thirsty!','Wilted tourists gasp for water at any price!',4,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(10,'Main Street Bakery Cupcakes',0,700,1750,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(11,'Dole Whips',0,1000,4400,10,'Bumper crop of pineapple means Dole Whip prices plummet!','Temporary cold snap means no one wants frozen treats.  Dole Whip prices fall.',4,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(12,'Casey\'s Corner Hot Dogs',0,1000,2500,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(13,'Pecos Bill\'s Veggie Burgers',0,1500,4400,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(14,'Tomorrowland Pretzels',0,2500,8900,5,'Pretzel-factory mistake means extra pretzels being thrown to guests along parade route.','Everyone goes on a carb-free diet. Pretzel sales fall.',3,5,'Eh, those carb-free diets were a fad.  Everyone wants pretzels!','Teenagers are buying pretzels at ridiculous prices!',3,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(15,'Tortuga Tavern\'s Taco Salads',0,1500,5400,10,'Taco salad demand drops when temporary heat wave hits the park.','Tabasco accident makes Guests scared to try the tacos.  Prices fall.',4,10,'Mad cow disease in Europe means tourists want American beef.  Taco salads for everyone!','There\'s something yummy in the salsa!  Demand for taco salads goes up.',4,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(16,'Green Peter Pan Hats',0,200,2000,20,'Prices for green felt hit rock bottom - Peter Pan Hat prices drop as a result.','Public decides green outfits are sooo last season.  Peter Pan Hat prices drop',3,8,'\"Germania\" hits the parks - everyone wants a Peter Pan Hat','Men are buying Peter Pan Hats at inflated prices.',5,'2012-06-29 00:00:00','2012-06-29 00:00:00');
/*!40000 ALTER TABLE `drugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_messages`
--

DROP TABLE IF EXISTS `encounter_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encounter_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_messages`
--

LOCK TABLES `encounter_messages` WRITE;
/*!40000 ALTER TABLE `encounter_messages` DISABLE KEYS */;
INSERT INTO `encounter_messages` VALUES (1,'You have been hit.',NULL,'2012-06-23 16:49:47','2012-06-23 16:49:47'),(2,'You got away.',NULL,'2012-06-23 16:49:47','2012-06-23 16:49:47'),(3,'You avoid harm.',NULL,'2012-06-23 16:50:34','2012-06-23 16:50:34'),(4,'You fail to get away.',NULL,'2012-06-23 16:50:34','2012-06-23 16:50:34'),(5,'You avoid harm.',NULL,'2012-06-23 16:50:36','2012-06-23 16:50:36'),(6,'You got away.',NULL,'2012-06-23 16:50:36','2012-06-23 16:50:36'),(7,'You avoid harm.',NULL,'2012-06-23 16:51:39','2012-06-23 16:51:39'),(8,'You got away.',NULL,'2012-06-23 16:51:39','2012-06-23 16:51:39'),(9,'You avoid harm.',NULL,'2012-06-23 16:52:42','2012-06-23 16:52:42'),(10,'You got away.',NULL,'2012-06-23 16:52:42','2012-06-23 16:52:42'),(11,'You have been hit.',NULL,'2012-06-23 16:53:50','2012-06-23 16:53:50'),(12,'You fail to get away.',NULL,'2012-06-23 16:53:50','2012-06-23 16:53:50'),(13,'You avoid harm.',NULL,'2012-06-23 16:53:53','2012-06-23 16:53:53'),(14,'You got away.',NULL,'2012-06-23 16:53:53','2012-06-23 16:53:53'),(15,'You have been hit.',NULL,'2012-06-23 16:57:38','2012-06-23 16:57:38'),(16,'You got away.',NULL,'2012-06-23 16:57:38','2012-06-23 16:57:38'),(17,'You have been hit.',NULL,'2012-06-23 16:58:45','2012-06-23 16:58:45'),(18,'You got away.',NULL,'2012-06-23 16:58:45','2012-06-23 16:58:45'),(19,'You avoid harm.',NULL,'2012-06-23 17:01:24','2012-06-23 17:01:24'),(20,'You got away.',NULL,'2012-06-23 17:01:24','2012-06-23 17:01:24'),(21,'You avoid harm.',NULL,'2012-06-23 17:03:46','2012-06-23 17:03:46'),(22,'You got away.',NULL,'2012-06-23 17:03:46','2012-06-23 17:03:46'),(23,'You avoid harm.',NULL,'2012-06-23 17:07:37','2012-06-23 17:07:37'),(24,'You got away.',NULL,'2012-06-23 17:07:37','2012-06-23 17:07:37'),(25,'You have been hit.',NULL,'2012-06-23 17:08:15','2012-06-23 17:08:15'),(26,'You got away.',NULL,'2012-06-23 17:08:15','2012-06-23 17:08:15'),(27,'You avoid harm.',NULL,'2012-06-23 17:08:41','2012-06-23 17:08:41'),(28,'You got away.',NULL,'2012-06-23 17:08:41','2012-06-23 17:08:41'),(29,'You avoid harm.',NULL,'2012-06-24 08:40:11','2012-06-24 08:40:11'),(30,'You fail to get away.',NULL,'2012-06-24 08:40:11','2012-06-24 08:40:11'),(31,'You avoid harm.',1,'2012-06-24 08:40:15','2012-06-24 08:40:15'),(32,'You got away.',1,'2012-06-24 08:40:15','2012-06-24 08:40:15'),(33,'You have been hit.',2,'2012-06-24 08:45:32','2012-06-24 08:45:32'),(34,'You got away.',2,'2012-06-24 08:45:32','2012-06-24 08:45:32'),(35,'You have been hit.',NULL,'2012-06-24 09:09:01','2012-06-24 09:09:01'),(36,'You fail to hurt the enemy.',NULL,'2012-06-24 09:09:01','2012-06-24 09:09:01'),(37,'You have been hit.',NULL,'2012-06-24 09:09:03','2012-06-24 09:09:03'),(38,'You fail to hurt the enemy.',NULL,'2012-06-24 09:09:03','2012-06-24 09:09:03'),(39,'You avoid harm.',NULL,'2012-06-24 09:09:05','2012-06-24 09:09:05'),(40,'You fail to hurt the enemy.',NULL,'2012-06-24 09:09:05','2012-06-24 09:09:05'),(41,'You have been hit.',NULL,'2012-06-24 09:09:06','2012-06-24 09:09:06'),(42,'You fail to hurt the enemy.',NULL,'2012-06-24 09:09:06','2012-06-24 09:09:06'),(43,'You have been hit.',NULL,'2012-06-24 09:09:07','2012-06-24 09:09:07'),(44,'You hurt the enemy.',NULL,'2012-06-24 09:09:07','2012-06-24 09:09:07'),(45,'You have been hit.',3,'2012-06-24 09:09:08','2012-06-24 09:09:08'),(46,'You avoid harm.',4,'2012-06-24 09:09:25','2012-06-24 09:09:25'),(47,'You got away.',4,'2012-06-24 09:09:25','2012-06-24 09:09:25'),(48,'You have been hit.',5,'2012-06-24 09:13:13','2012-06-24 09:13:13'),(49,'You fail to get away.',5,'2012-06-24 09:13:13','2012-06-24 09:13:13'),(50,'You have been hit.',NULL,'2012-06-24 09:22:25','2012-06-24 09:22:25'),(51,'You fail to get away.',NULL,'2012-06-24 09:22:25','2012-06-24 09:22:25'),(52,'You have been hit.',NULL,'2012-06-24 09:22:27','2012-06-24 09:22:27'),(53,'You fail to get away.',NULL,'2012-06-24 09:22:27','2012-06-24 09:22:27'),(54,'You avoid harm.',NULL,'2012-06-24 09:22:28','2012-06-24 09:22:28'),(55,'You fail to get away.',NULL,'2012-06-24 09:22:28','2012-06-24 09:22:28'),(56,'You have been hit.',6,'2012-06-24 09:22:29','2012-06-24 09:22:29'),(57,'You got away.',6,'2012-06-24 09:22:29','2012-06-24 09:22:29'),(58,'You have been hit.',7,'2012-06-24 09:22:47','2012-06-24 09:22:47'),(59,'You got away.',7,'2012-06-24 09:22:47','2012-06-24 09:22:47'),(60,'You are searched and sent on your way.',8,'2012-06-24 09:23:32','2012-06-24 09:23:32'),(61,'You are searched and sent on your way.',9,'2012-06-24 09:24:14','2012-06-24 09:24:14'),(62,'You avoid harm.',10,'2012-06-24 09:25:54','2012-06-24 09:25:54'),(63,'You got away.',10,'2012-06-24 09:25:54','2012-06-24 09:25:54'),(64,'You have been hit.',11,'2012-06-24 09:26:29','2012-06-24 09:26:29'),(65,'You fail to get away.',11,'2012-06-24 09:26:29','2012-06-24 09:26:29'),(66,'You avoid harm.',12,'2012-06-28 19:53:45','2012-06-28 19:53:45'),(67,'You got away.',12,'2012-06-28 19:53:45','2012-06-28 19:53:45'),(68,'You are searched and sent on your way.',13,'2012-06-29 13:05:22','2012-06-29 13:05:22'),(69,'You are searched and sent on your way.',14,'2012-06-29 13:11:32','2012-06-29 13:11:32'),(70,'You are searched and sent on your way.',15,'2012-06-29 13:11:55','2012-06-29 13:11:55'),(71,'You avoid harm.',NULL,'2012-06-29 19:11:36','2012-06-29 19:11:36'),(72,'You fail to get away.',NULL,'2012-06-29 19:11:36','2012-06-29 19:11:36'),(73,'You avoid harm.',NULL,'2012-06-29 19:11:44','2012-06-29 19:11:44'),(74,'You fail to get away.',NULL,'2012-06-29 19:11:44','2012-06-29 19:11:44'),(75,'You have been hit.',16,'2012-06-29 19:11:49','2012-06-29 19:11:49'),(76,'You got away.',16,'2012-06-29 19:11:49','2012-06-29 19:11:49'),(77,'You have been hit.',17,'2012-06-29 19:12:42','2012-06-29 19:12:42'),(78,'You got away.',17,'2012-06-29 19:12:42','2012-06-29 19:12:42'),(79,'You have been hit.',18,'2012-06-29 19:13:35','2012-06-29 19:13:35'),(80,'You got away.',18,'2012-06-29 19:13:35','2012-06-29 19:13:35'),(81,'You are searched and sent on your way.',19,'2012-06-29 19:14:40','2012-06-29 19:14:40'),(82,'You are searched and sent on your way.',20,'2012-06-29 19:15:10','2012-06-29 19:15:10'),(83,'You have been hit.',NULL,'2012-06-29 19:36:49','2012-06-29 19:36:49'),(84,'One of your followers goes down.',NULL,'2012-06-29 19:36:49','2012-06-29 19:36:49'),(85,'You fail to hurt the enemy.',NULL,'2012-06-29 19:36:49','2012-06-29 19:36:49'),(86,'You avoid harm.',NULL,'2012-06-29 19:37:38','2012-06-29 19:37:38'),(87,'You fail to hurt the enemy.',NULL,'2012-06-29 19:37:38','2012-06-29 19:37:38'),(88,'You avoid harm.',NULL,'2012-06-29 19:37:45','2012-06-29 19:37:45'),(89,'You fail to hurt the enemy.',NULL,'2012-06-29 19:37:45','2012-06-29 19:37:45'),(90,'You have been hit.',NULL,'2012-06-29 19:37:47','2012-06-29 19:37:47'),(91,'You fail to hurt the enemy.',NULL,'2012-06-29 19:37:47','2012-06-29 19:37:47'),(92,'You have been hit.',NULL,'2012-06-29 19:38:03','2012-06-29 19:38:03'),(93,'You fail to hurt the enemy.',NULL,'2012-06-29 19:38:03','2012-06-29 19:38:03'),(94,'You avoid harm.',NULL,'2012-06-29 19:38:05','2012-06-29 19:38:05'),(95,'You fail to get away.',NULL,'2012-06-29 19:38:05','2012-06-29 19:38:05'),(96,'You have been hit.',21,'2012-06-29 19:38:07','2012-06-29 19:38:07'),(97,'You got away.',21,'2012-06-29 19:38:07','2012-06-29 19:38:07'),(98,'You have been hit.',NULL,'2012-06-29 19:47:15','2012-06-29 19:47:15'),(99,'You fail to get away.',NULL,'2012-06-29 19:47:15','2012-06-29 19:47:15'),(100,'You have been hit.',22,'2012-06-29 19:47:46','2012-06-29 19:47:46'),(101,'You fail to get away.',22,'2012-06-29 19:47:46','2012-06-29 19:47:46'),(102,'You have been hit.',23,'2012-06-29 20:01:18','2012-06-29 20:01:18'),(103,'You got away.',23,'2012-06-29 20:01:18','2012-06-29 20:01:18'),(104,'You avoid harm.',24,'2012-06-29 21:21:53','2012-06-29 21:21:53'),(105,'You got away.',24,'2012-06-29 21:21:53','2012-06-29 21:21:53'),(106,'You avoid harm.',25,'2012-06-29 21:45:35','2012-06-29 21:45:35'),(107,'You got away.',25,'2012-06-29 21:45:35','2012-06-29 21:45:35'),(108,'You have been hit.',NULL,'2012-06-29 23:45:14','2012-06-29 23:45:14'),(109,'You have stunned the enemy.',NULL,'2012-06-29 23:45:14','2012-06-29 23:45:14'),(110,'You have been hit.',NULL,'2012-06-29 23:45:17','2012-06-29 23:45:17'),(111,'You have stunned the enemy.',NULL,'2012-06-29 23:45:17','2012-06-29 23:45:17'),(112,'You have been hit.',NULL,'2012-06-29 23:45:21','2012-06-29 23:45:21'),(113,'You have stunned the enemy.',NULL,'2012-06-29 23:45:21','2012-06-29 23:45:21'),(114,'You have been hit.',NULL,'2012-06-29 23:45:25','2012-06-29 23:45:25'),(115,'You have stunned the enemy.',NULL,'2012-06-29 23:45:26','2012-06-29 23:45:26'),(116,'You have been hit.',NULL,'2012-06-29 23:45:28','2012-06-29 23:45:28'),(117,'You have stunned the enemy.',NULL,'2012-06-29 23:45:28','2012-06-29 23:45:28'),(118,'You have been hit.',NULL,'2012-06-29 23:45:30','2012-06-29 23:45:30'),(119,'You have stunned the enemy.',NULL,'2012-06-29 23:45:30','2012-06-29 23:45:30'),(120,'You avoid harm.',NULL,'2012-06-29 23:45:31','2012-06-29 23:45:31'),(121,'You have stunned the enemy.',NULL,'2012-06-29 23:45:31','2012-06-29 23:45:31'),(122,'You avoid harm.',NULL,'2012-06-29 23:45:33','2012-06-29 23:45:33'),(123,'You fail to stunned the enemy.',NULL,'2012-06-29 23:45:33','2012-06-29 23:45:33'),(124,'You avoid harm.',NULL,'2012-06-29 23:45:37','2012-06-29 23:45:37'),(125,'You fail to stunned the enemy.',NULL,'2012-06-29 23:45:37','2012-06-29 23:45:37'),(126,'You have been hit.',NULL,'2012-06-29 23:45:40','2012-06-29 23:45:40'),(127,'You fail to stunned the enemy.',NULL,'2012-06-29 23:45:40','2012-06-29 23:45:40'),(128,'You have been hit.',NULL,'2012-06-29 23:45:42','2012-06-29 23:45:42'),(129,'You have stunned the enemy.',NULL,'2012-06-29 23:45:42','2012-06-29 23:45:42'),(130,'You avoid harm.',NULL,'2012-06-29 23:45:44','2012-06-29 23:45:44'),(131,'You fail to stunned the enemy.',NULL,'2012-06-29 23:45:44','2012-06-29 23:45:44'),(132,'You avoid harm.',26,'2012-06-29 23:45:46','2012-06-29 23:45:46'),(133,'You have stunned the enemy.',26,'2012-06-29 23:45:46','2012-06-29 23:45:46'),(134,'You win and find $653',26,'2012-06-29 23:45:46','2012-06-29 23:45:46'),(135,'You have been hit.',NULL,'2012-06-29 23:48:04','2012-06-29 23:48:04'),(136,'You fail to get away.',NULL,'2012-06-29 23:48:04','2012-06-29 23:48:04'),(137,'You avoid harm.',27,'2012-06-29 23:48:07','2012-06-29 23:48:07'),(138,'You got away.',27,'2012-06-29 23:48:07','2012-06-29 23:48:07'),(139,'You have been hit.',28,'2012-06-29 23:51:53','2012-06-29 23:51:53'),(140,'You got away.',28,'2012-06-29 23:51:53','2012-06-29 23:51:53'),(141,'You have been hit.',29,'2012-06-29 23:52:44','2012-06-29 23:52:44'),(142,'You got away.',29,'2012-06-29 23:52:44','2012-06-29 23:52:44'),(143,'You have been hit.',30,'2012-06-29 23:53:03','2012-06-29 23:53:03'),(144,'You got away.',30,'2012-06-29 23:53:03','2012-06-29 23:53:03'),(145,'You have been hit.',31,'2012-06-29 23:53:11','2012-06-29 23:53:11'),(146,'You got away.',31,'2012-06-29 23:53:11','2012-06-29 23:53:11'),(147,'You are searched and sent on your way.',32,'2012-06-29 23:53:32','2012-06-29 23:53:32'),(148,'You are searched and sent on your way.',33,'2012-06-29 23:54:07','2012-06-29 23:54:07'),(149,'You avoid harm.',34,'2012-06-29 23:54:27','2012-06-29 23:54:27'),(150,'You got away.',34,'2012-06-29 23:54:27','2012-06-29 23:54:27');
/*!40000 ALTER TABLE `encounter_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounters`
--

DROP TABLE IF EXISTS `encounters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encounters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `current_endurance` int(11) DEFAULT NULL,
  `cash` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounters`
--

LOCK TABLES `encounters` WRITE;
/*!40000 ALTER TABLE `encounters` DISABLE KEYS */;
/*!40000 ALTER TABLE `encounters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_masters`
--

DROP TABLE IF EXISTS `event_masters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_masters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `event_chance` int(11) DEFAULT NULL,
  `event_type` int(11) DEFAULT NULL,
  `type_arg1` int(11) DEFAULT NULL,
  `type_arg2` int(11) DEFAULT NULL,
  `type_arg3` int(11) DEFAULT NULL,
  `type_arg4` int(11) DEFAULT NULL,
  `message_str` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_masters`
--

LOCK TABLES `event_masters` WRITE;
/*!40000 ALTER TABLE `event_masters` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_masters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `event_type` int(11) DEFAULT NULL,
  `type_arg1` int(11) DEFAULT NULL,
  `type_arg2` int(11) DEFAULT NULL,
  `type_arg3` int(11) DEFAULT NULL,
  `type_arg4` int(11) DEFAULT NULL,
  `message_str` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follower_types`
--

DROP TABLE IF EXISTS `follower_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `follower_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accuracy` int(11) DEFAULT NULL,
  `endurance` int(11) DEFAULT NULL,
  `evasion` int(11) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `spaces` int(11) DEFAULT NULL,
  `hirable` tinyint(1) DEFAULT NULL,
  `min_price` int(11) DEFAULT NULL,
  `max_price` int(11) DEFAULT NULL,
  `clean` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follower_types`
--

LOCK TABLES `follower_types` WRITE;
/*!40000 ALTER TABLE `follower_types` DISABLE KEYS */;
INSERT INTO `follower_types` VALUES (1,'Castmember',15,10,25,15,10,0,25000,80000,1,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(2,'Manager',35,20,25,25,10,0,50000,160000,1,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(3,'Area Manager',45,30,35,45,10,0,80000,200000,1,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(4,'a friend',35,10,45,45,10,1,50000,160000,0,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(5,'a rogue Guest',45,20,35,35,10,0,60000,180000,0,'2012-06-23 16:45:22','2012-06-23 16:45:22');
/*!40000 ALTER TABLE `follower_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `followers`
--

DROP TABLE IF EXISTS `followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `current_endurance` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `followers`
--

LOCK TABLES `followers` WRITE;
/*!40000 ALTER TABLE `followers` DISABLE KEYS */;
INSERT INTO `followers` VALUES (1,'Deputy',10,1,NULL,2,'2012-06-23 16:50:31','2012-06-23 16:50:31'),(2,'Deputy',8,1,NULL,3,'2012-06-23 16:51:36','2012-06-24 09:09:07'),(3,'Deputy',10,1,NULL,3,'2012-06-23 16:51:36','2012-06-23 16:51:36'),(4,'Deputy',10,1,NULL,4,'2012-06-23 16:52:40','2012-06-23 16:52:40'),(5,'Deputy',10,1,NULL,4,'2012-06-23 16:52:40','2012-06-23 16:52:40'),(6,'Deputy',10,1,NULL,5,'2012-06-23 16:53:48','2012-06-23 16:53:48'),(7,'Deputy',10,1,NULL,6,'2012-06-23 16:57:36','2012-06-23 16:57:36'),(8,'Deputy',10,1,NULL,6,'2012-06-23 16:57:36','2012-06-23 16:57:36'),(9,'Deputy',10,1,NULL,7,'2012-06-23 16:58:43','2012-06-23 16:58:43'),(10,'Deputy',10,1,NULL,7,'2012-06-23 16:58:43','2012-06-23 16:58:43'),(11,'Deputy',10,1,NULL,8,'2012-06-23 17:01:21','2012-06-23 17:01:21'),(12,'Deputy',10,1,NULL,9,'2012-06-23 17:03:44','2012-06-23 17:03:44'),(13,'Deputy',10,1,NULL,9,'2012-06-23 17:03:44','2012-06-23 17:03:44'),(15,'Deputy',10,1,NULL,11,'2012-06-23 17:08:13','2012-06-23 17:08:13'),(16,'Deputy',10,1,NULL,11,'2012-06-23 17:08:13','2012-06-23 17:08:13'),(17,'Castmember',10,1,NULL,3,'2012-06-24 09:08:36','2012-06-24 09:08:36'),(18,'Castmember',10,1,NULL,4,'2012-06-24 09:09:23','2012-06-24 09:09:23'),(19,'Castmember',10,1,NULL,5,'2012-06-24 09:13:10','2012-06-24 09:13:10'),(20,'Castmember',10,1,NULL,5,'2012-06-24 09:13:10','2012-06-24 09:13:10'),(21,'Castmember',10,1,NULL,6,'2012-06-24 09:20:57','2012-06-24 09:20:57'),(22,'Castmember',10,1,NULL,6,'2012-06-24 09:20:57','2012-06-24 09:20:57'),(23,'Castmember',10,1,NULL,7,'2012-06-24 09:22:45','2012-06-24 09:22:45'),(24,'Castmember',10,1,NULL,8,'2012-06-24 09:23:28','2012-06-24 09:23:28'),(25,'Castmember',10,1,NULL,8,'2012-06-24 09:23:28','2012-06-24 09:23:28'),(26,'Castmember',10,1,NULL,11,'2012-06-24 09:26:26','2012-06-24 09:26:26'),(27,'Castmember',10,1,NULL,12,'2012-06-28 19:53:29','2012-06-28 19:53:29'),(28,'Castmember',10,1,NULL,12,'2012-06-28 19:53:29','2012-06-28 19:53:29'),(29,'Castmember',10,1,NULL,13,'2012-06-29 13:03:41','2012-06-29 13:03:41'),(30,'Castmember',10,1,NULL,13,'2012-06-29 13:03:41','2012-06-29 13:03:41'),(31,'Castmember',10,1,NULL,14,'2012-06-29 13:11:27','2012-06-29 13:11:27'),(32,'Castmember',10,1,NULL,15,'2012-06-29 13:11:47','2012-06-29 13:11:47'),(33,'Castmember',10,1,NULL,16,'2012-06-29 19:11:25','2012-06-29 19:11:25'),(34,'Castmember',10,1,NULL,16,'2012-06-29 19:11:25','2012-06-29 19:11:25'),(35,'Castmember',10,1,NULL,17,'2012-06-29 19:12:36','2012-06-29 19:12:36'),(37,'Castmember',10,1,NULL,18,'2012-06-29 19:13:32','2012-06-29 19:13:32'),(38,'Castmember',10,1,NULL,18,'2012-06-29 19:13:32','2012-06-29 19:13:32'),(39,'Castmember',10,1,NULL,19,'2012-06-29 19:14:38','2012-06-29 19:14:38'),(40,'Castmember',10,1,NULL,19,'2012-06-29 19:14:38','2012-06-29 19:14:38'),(41,'Castmember',10,1,NULL,21,'2012-06-29 19:24:46','2012-06-29 19:24:46'),(42,'Castmember',10,1,NULL,21,'2012-06-29 19:24:46','2012-06-29 19:24:46'),(43,'Castmember',10,1,NULL,22,'2012-06-29 19:44:53','2012-06-29 19:44:53'),(44,'Castmember',10,1,NULL,22,'2012-06-29 19:44:53','2012-06-29 19:44:53'),(45,'Castmember',10,1,NULL,23,'2012-06-29 20:01:08','2012-06-29 20:01:08'),(46,'Castmember',10,1,NULL,23,'2012-06-29 20:01:08','2012-06-29 20:01:08'),(47,'Castmember',10,1,NULL,24,'2012-06-29 21:21:24','2012-06-29 21:21:24'),(48,'Manager',20,2,NULL,27,'2012-06-29 23:47:59','2012-06-29 23:47:59'),(49,'Manager',20,2,NULL,27,'2012-06-29 23:47:59','2012-06-29 23:47:59'),(51,'Castmember',10,1,NULL,28,'2012-06-29 23:51:46','2012-06-29 23:51:46'),(52,'Castmember',10,1,NULL,29,'2012-06-29 23:52:41','2012-06-29 23:52:41'),(53,'Castmember',10,1,NULL,29,'2012-06-29 23:52:41','2012-06-29 23:52:41'),(54,'Castmember',10,1,NULL,31,'2012-06-29 23:53:09','2012-06-29 23:53:09'),(55,'Castmember',10,1,NULL,31,'2012-06-29 23:53:09','2012-06-29 23:53:09'),(56,'Castmember',10,1,NULL,32,'2012-06-29 23:53:29','2012-06-29 23:53:29'),(57,'Castmember',10,1,NULL,32,'2012-06-29 23:53:29','2012-06-29 23:53:29'),(58,'Castmember',10,1,NULL,33,'2012-06-29 23:54:01','2012-06-29 23:54:01'),(59,'Castmember',10,1,NULL,33,'2012-06-29 23:54:01','2012-06-29 23:54:01');
/*!40000 ALTER TABLE `followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gun_instances`
--

DROP TABLE IF EXISTS `gun_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gun_instances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `encounter_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gun_instances`
--

LOCK TABLES `gun_instances` WRITE;
/*!40000 ALTER TABLE `gun_instances` DISABLE KEYS */;
INSERT INTO `gun_instances` VALUES (1,'Souvenir t-shirt',3,NULL,1,'2012-06-23 16:49:44','2012-06-23 16:49:44'),(2,'Souvenir sweatshirt',3,NULL,2,'2012-06-23 16:50:31','2012-06-23 16:50:31'),(3,'Mouse ears',2,NULL,3,'2012-06-23 16:50:31','2012-06-23 16:50:31'),(4,'Vinylmation',3,NULL,4,'2012-06-23 16:51:36','2012-06-23 16:51:36'),(5,'Adventureland pin',2,NULL,5,'2012-06-23 16:51:36','2012-06-23 16:51:36'),(6,'Main Street pin',2,NULL,6,'2012-06-23 16:51:36','2012-06-23 16:51:36'),(7,'Frontierland pin',3,NULL,7,'2012-06-23 16:52:40','2012-06-23 16:52:40'),(8,'Liberty Square pin',2,NULL,8,'2012-06-23 16:52:40','2012-06-23 16:52:40'),(9,'Fantasyland pin',2,NULL,9,'2012-06-23 16:52:40','2012-06-23 16:52:40'),(10,'Tomorrowland pin',3,NULL,10,'2012-06-23 16:53:48','2012-06-23 16:53:48'),(11,'Plush character doll',2,NULL,11,'2012-06-23 16:53:48','2012-06-23 16:53:48'),(12,'Flip-flops',3,NULL,12,'2012-06-23 16:57:36','2012-06-23 16:57:36'),(13,'A big, floppy  hat',2,NULL,1,'2012-06-23 16:57:36','2012-06-23 16:57:36'),(14,'Sunscreen',2,NULL,2,'2012-06-23 16:57:36','2012-06-23 16:57:36'),(15,'A battery-powered water mister',3,NULL,3,'2012-06-23 16:58:43','2012-06-23 16:58:43'),(16,'A refillable mug',2,NULL,4,'2012-06-23 16:58:43','2012-06-23 16:58:43'),(17,'Buzz Lightyear ride photo',2,NULL,5,'2012-06-23 16:58:43','2012-06-23 16:58:43'),(18,'Space Mountain ride photo',3,NULL,6,'2012-06-23 17:01:21','2012-06-23 17:01:21'),(19,'Rain poncho',2,NULL,7,'2012-06-23 17:01:21','2012-06-23 17:01:21'),(20,'Splash Mountain ride photo',3,NULL,8,'2012-06-23 17:03:44','2012-06-23 17:03:44'),(21,'Hat from a Jungle Cruise skipper',2,NULL,9,'2012-06-23 17:03:44','2012-06-23 17:03:44'),(22,'Parrot from Tiki Room',2,NULL,10,'2012-06-23 17:03:44','2012-06-23 17:03:44'),(23,'Princess tiara from Main Street',3,NULL,11,'2012-06-23 17:07:35','2012-06-23 17:07:35'),(24,'Ticket lanyard',3,NULL,12,'2012-06-23 17:08:13','2012-06-23 17:08:13'),(31,'Ruger',3,NULL,3,'2012-06-24 09:08:36','2012-06-24 09:08:36'),(32,'Baretta',2,NULL,3,'2012-06-24 09:08:36','2012-06-24 09:08:36'),(33,'Ruger',3,NULL,4,'2012-06-24 09:09:23','2012-06-24 09:09:23'),(34,'Baretta',2,NULL,4,'2012-06-24 09:09:23','2012-06-24 09:09:23'),(35,'Ruger',3,NULL,5,'2012-06-24 09:13:10','2012-06-24 09:13:10'),(36,'Baretta',2,NULL,5,'2012-06-24 09:13:10','2012-06-24 09:13:10'),(37,'Baretta',2,NULL,5,'2012-06-24 09:13:10','2012-06-24 09:13:10'),(38,'Ruger',3,NULL,6,'2012-06-24 09:20:57','2012-06-24 09:20:57'),(39,'Baretta',2,NULL,6,'2012-06-24 09:20:57','2012-06-24 09:20:57'),(40,'Baretta',2,NULL,6,'2012-06-24 09:20:57','2012-06-24 09:20:57'),(41,'guns3',3,NULL,7,'2012-06-24 09:22:45','2012-06-24 09:22:45'),(42,'guns2',2,NULL,7,'2012-06-24 09:22:45','2012-06-24 09:22:45'),(43,'guns3',3,NULL,8,'2012-06-24 09:23:28','2012-06-24 09:23:28'),(44,'guns2',2,NULL,8,'2012-06-24 09:23:28','2012-06-24 09:23:28'),(45,'guns2',2,NULL,8,'2012-06-24 09:23:28','2012-06-24 09:23:28'),(46,'guns3',3,NULL,9,'2012-06-24 09:24:11','2012-06-24 09:24:11'),(47,'guns3',3,NULL,10,'2012-06-24 09:25:52','2012-06-24 09:25:52'),(48,'guns3',3,NULL,11,'2012-06-24 09:26:26','2012-06-24 09:26:26'),(49,'guns2',2,NULL,11,'2012-06-24 09:26:26','2012-06-24 09:26:26'),(50,'guns3',3,NULL,12,'2012-06-28 19:53:29','2012-06-28 19:53:29'),(51,'guns2',2,NULL,12,'2012-06-28 19:53:29','2012-06-28 19:53:29'),(52,'guns2',2,NULL,12,'2012-06-28 19:53:29','2012-06-28 19:53:29'),(53,'Bottle of \"Tour Group Body Odor\"',3,NULL,13,'2012-06-29 13:03:41','2012-06-29 13:03:41'),(54,'Sudden Burst of Humidity',2,NULL,13,'2012-06-29 13:03:41','2012-06-29 13:03:41'),(55,'Sudden Burst of Humidity',2,NULL,13,'2012-06-29 13:03:41','2012-06-29 13:03:41'),(56,'Bottle of \"Tour Group Body Odor\"',3,NULL,14,'2012-06-29 13:11:27','2012-06-29 13:11:27'),(57,'Sudden Burst of Humidity',2,NULL,14,'2012-06-29 13:11:27','2012-06-29 13:11:27'),(58,'Bottle of \"Tour Group Body Odor\"',3,NULL,15,'2012-06-29 13:11:47','2012-06-29 13:11:47'),(59,'Sudden Burst of Humidity',2,NULL,15,'2012-06-29 13:11:47','2012-06-29 13:11:47'),(60,'Bottle of \"Tour Group Body Odor\"',3,NULL,16,'2012-06-29 19:11:25','2012-06-29 19:11:25'),(61,'Sudden Burst of Humidity',2,NULL,16,'2012-06-29 19:11:25','2012-06-29 19:11:25'),(62,'Sudden Burst of Humidity',2,NULL,16,'2012-06-29 19:11:25','2012-06-29 19:11:25'),(63,'Bottle of \"Tour Group Body Odor\"',3,NULL,17,'2012-06-29 19:12:36','2012-06-29 19:12:36'),(64,'Sudden Burst of Humidity',2,NULL,17,'2012-06-29 19:12:36','2012-06-29 19:12:36'),(65,'Bottle of \"Tour Group Body Odor\"',3,NULL,18,'2012-06-29 19:13:32','2012-06-29 19:13:32'),(66,'Sudden Burst of Humidity',2,NULL,18,'2012-06-29 19:13:32','2012-06-29 19:13:32'),(67,'Sudden Burst of Humidity',2,NULL,18,'2012-06-29 19:13:32','2012-06-29 19:13:32'),(68,'Bottle of \"Tour Group Body Odor\"',3,NULL,19,'2012-06-29 19:14:38','2012-06-29 19:14:38'),(69,'Sudden Burst of Humidity',2,NULL,19,'2012-06-29 19:14:38','2012-06-29 19:14:38'),(70,'Sudden Burst of Humidity',2,NULL,19,'2012-06-29 19:14:38','2012-06-29 19:14:38'),(71,'Bottle of \"Tour Group Body Odor\"',3,NULL,20,'2012-06-29 19:15:07','2012-06-29 19:15:07'),(73,'Bottle of \"Tour Group Body Odor\"',3,NULL,21,'2012-06-29 19:24:46','2012-06-29 19:24:46'),(74,'Sudden Burst of Humidity',2,NULL,21,'2012-06-29 19:24:46','2012-06-29 19:24:46'),(75,'Sudden Burst of Humidity',2,NULL,21,'2012-06-29 19:24:46','2012-06-29 19:24:46'),(77,'Bottle of \"Tour Group Body Odor\"',3,NULL,22,'2012-06-29 19:44:53','2012-06-29 19:44:53'),(78,'Sudden Burst of Humidity',2,NULL,22,'2012-06-29 19:44:53','2012-06-29 19:44:53'),(79,'Sudden Burst of Humidity',2,NULL,22,'2012-06-29 19:44:53','2012-06-29 19:44:53'),(80,'Bottle of \"Tour Group Body Odor\"',3,NULL,23,'2012-06-29 20:01:08','2012-06-29 20:01:08'),(81,'Sudden Burst of Humidity',2,NULL,23,'2012-06-29 20:01:08','2012-06-29 20:01:08'),(82,'Sudden Burst of Humidity',2,NULL,23,'2012-06-29 20:01:08','2012-06-29 20:01:08'),(83,'Bottle of \"Tour Group Body Odor\"',3,NULL,24,'2012-06-29 21:21:24','2012-06-29 21:21:24'),(84,'Sudden Burst of Humidity',2,NULL,24,'2012-06-29 21:21:24','2012-06-29 21:21:24'),(85,'Bottle of \"Tour Group Body Odor\"',3,NULL,25,'2012-06-29 21:45:21','2012-06-29 21:45:21'),(89,'Cursed Spinning Wheel',4,NULL,27,'2012-06-29 23:47:59','2012-06-29 23:47:59'),(90,'Bottle of \"Tour Group Body Odor\"',3,NULL,27,'2012-06-29 23:47:59','2012-06-29 23:47:59'),(91,'Bottle of \"Tour Group Body Odor\"',3,NULL,27,'2012-06-29 23:47:59','2012-06-29 23:47:59'),(92,'Bottle of \"Tour Group Body Odor\"',3,NULL,28,'2012-06-29 23:51:46','2012-06-29 23:51:46'),(93,'Sudden Burst of Humidity',2,NULL,28,'2012-06-29 23:51:46','2012-06-29 23:51:46'),(94,'Bottle of \"Tour Group Body Odor\"',3,NULL,29,'2012-06-29 23:52:41','2012-06-29 23:52:41'),(95,'Sudden Burst of Humidity',2,NULL,29,'2012-06-29 23:52:41','2012-06-29 23:52:41'),(96,'Sudden Burst of Humidity',2,NULL,29,'2012-06-29 23:52:41','2012-06-29 23:52:41'),(97,'Bottle of \"Tour Group Body Odor\"',3,NULL,30,'2012-06-29 23:53:01','2012-06-29 23:53:01'),(98,'Bottle of \"Tour Group Body Odor\"',3,NULL,31,'2012-06-29 23:53:09','2012-06-29 23:53:09'),(99,'Sudden Burst of Humidity',2,NULL,31,'2012-06-29 23:53:09','2012-06-29 23:53:09'),(100,'Sudden Burst of Humidity',2,NULL,31,'2012-06-29 23:53:09','2012-06-29 23:53:09'),(101,'Bottle of \"Tour Group Body Odor\"',3,NULL,32,'2012-06-29 23:53:29','2012-06-29 23:53:29'),(102,'Sudden Burst of Humidity',2,NULL,32,'2012-06-29 23:53:29','2012-06-29 23:53:29'),(103,'Sudden Burst of Humidity',2,NULL,32,'2012-06-29 23:53:29','2012-06-29 23:53:29'),(104,'Bottle of \"Tour Group Body Odor\"',3,NULL,33,'2012-06-29 23:54:01','2012-06-29 23:54:01'),(105,'Sudden Burst of Humidity',2,NULL,33,'2012-06-29 23:54:01','2012-06-29 23:54:01'),(106,'Sudden Burst of Humidity',2,NULL,33,'2012-06-29 23:54:01','2012-06-29 23:54:01'),(107,'Bottle of \"Tour Group Body Odor\"',3,NULL,34,'2012-06-29 23:54:25','2012-06-29 23:54:25');
/*!40000 ALTER TABLE `gun_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guns`
--

DROP TABLE IF EXISTS `guns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `clean` tinyint(1) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `space` int(11) DEFAULT NULL,
  `damage` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guns`
--

LOCK TABLES `guns` WRITE;
/*!40000 ALTER TABLE `guns` DISABLE KEYS */;
INSERT INTO `guns` VALUES (1,'Magic Apple',0,1900,2,2,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(2,'Sudden Burst of Humidity',0,2900,4,4,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(3,'Bottle of \"Tour Group Body Odor\"',0,3800,4,5,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(4,'Cursed Spinning Wheel',0,5500,4,7,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(5,'Magic Wand',0,7200,4,9,'2012-06-23 16:45:22','2012-06-23 16:45:22'),(6,'Enchanted Mirror',0,15000,8,18,'2012-06-23 16:45:22','2012-06-23 16:45:22');
/*!40000 ALTER TABLE `guns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `high_scores`
--

DROP TABLE IF EXISTS `high_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `high_scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `alive` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `high_scores`
--

LOCK TABLES `high_scores` WRITE;
/*!40000 ALTER TABLE `high_scores` DISABLE KEYS */;
INSERT INTO `high_scores` VALUES (1,'len',1214989,1,'2012-06-23 17:09:14','2012-06-23 17:09:14'),(2,'len',114423,1,'2012-06-24 09:13:13','2012-06-24 09:13:13'),(3,'len',-22508,1,'2012-06-24 09:26:29','2012-06-24 09:26:29'),(4,'len',4287172,1,'2012-06-29 19:47:46','2012-06-29 19:47:46'),(5,'len',684365,1,'2012-06-29 23:49:38','2012-06-29 23:49:38'),(6,'len',-22891,1,'2012-06-29 23:54:41','2012-06-29 23:54:41');
/*!40000 ALTER TABLE `high_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (155,'Management puts Space\'s standby line outside to save on air-conditioning costs.  FASTPASS prices take off like a rocket!','1','2012-06-30 00:17:24','2012-06-30 00:17:24');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20120515211248'),('20120515211249'),('20120516041229'),('20120517004539'),('20120517011249'),('20120517013506'),('20120517014017'),('20120517014629'),('20120517065313'),('20120518014948'),('20120518192825'),('20120518204025'),('20120518204141'),('20120518204455'),('20120518205015'),('20120518210921'),('20120519055936'),('20120523001005'),('20120523001556'),('20120523015933'),('20120524004119');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shops`
--

DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1511 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shops`
--

LOCK TABLES `shops` WRITE;
/*!40000 ALTER TABLE `shops` DISABLE KEYS */;
INSERT INTO `shops` VALUES (1502,'Bottles of Water',902,9,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1503,'Main Street Bakery Cupcakes',1253,10,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1504,'Dole Whips',2326,11,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1505,'Jungle Cruise FASTPASSes',1118,8,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1506,'Pecos Bill\'s Veggie Burgers',2938,13,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1507,'Space Mountain FASTPASSes',66,1,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1508,'Big Thunder Mountain FASTPASSes',997,7,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1509,'Casey\'s Corner Hot Dogs',1877,12,1,'2012-06-30 00:17:24','2012-06-30 00:17:24'),(1510,'Dumbo FASTPASSes',327,4,1,'2012-06-30 00:17:24','2012-06-30 00:17:24');
/*!40000 ALTER TABLE `shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wallet` int(11) DEFAULT NULL,
  `days_remaining` int(11) DEFAULT NULL,
  `end_of_turn` tinyint(1) DEFAULT NULL,
  `free` tinyint(1) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `accuracy` int(11) DEFAULT NULL,
  `evasion` int(11) DEFAULT NULL,
  `endurance` int(11) DEFAULT NULL,
  `current_endurance` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `nextaction` int(11) DEFAULT NULL,
  `spaces` int(11) DEFAULT NULL,
  `location` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'len','f76984c0e01f2680decdcfd6b8643ff4','41369',2376,18,0,1,50,50,50,100,100,0,NULL,100,8,'2012-06-23 16:46:04','2012-06-30 00:18:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-06-30 18:28:22
